//
//  main.m
//  AJActionsheetView
//
//  Created by 安俊 on 16/5/19.
//  Copyright © 2016年 anjun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
