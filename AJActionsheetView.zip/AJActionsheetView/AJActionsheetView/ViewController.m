//
//  ViewController.m
//  AJActionsheetView
//
//  Created by anjun on 16/5/19.
//  Copyright © 2016年 anjun. All rights reserved.
//
//
//
//
//
//  仿微信弹框效果
//
//
//
//

#import "ViewController.h"
#import "CustomActionSheet.h"

// 遵守协议
@interface ViewController ()<CustomActionSheetDelagate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    // 具体使用方法:就这三句代码
    CustomActionSheet * mySheet = [[CustomActionSheet alloc] initWithTitle:@"这里是标题" otherButtonTitles:@[@"选项一",@"选项二",@"选项三"]];
    mySheet.delegate = self;
    [mySheet show];
}

#pragma mark - delegate
// 在代理方法中写你需要处理的点击事件逻辑即可
- (void)sheet:(CustomActionSheet *)sheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSLog(@"you has clicked button ======= %ld",(long)buttonIndex);
}

@end
